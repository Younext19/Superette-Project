package com.damso.superette;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.damso.superette.database.Item;

import java.util.Collections;
import java.util.List;

public class More_Details extends AppCompatActivity {
    TextView Marque;
    TextView Type;
    TextView Volume;
    TextView Prix;
    TextView Code_Bar;
    TextView Composition;
    TextView Energie;
    TextView Matiere_Graisse;
    TextView Graisse_Sature;
    TextView Glucides;
    TextView Sucre;
    TextView Proteine;
    TextView Sodium;
    TextView Sel;

    String marque;
    String type;
    String volume;
    String prix;
    String code_bar;
    String composition;
    String energie;
    String matiere_graisse;
    String graisse_sature;
    String glucides;
    String sucre;
    String proteine;
    String sodium;
    String sel;
    List<Item> items= Collections.emptyList();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_more__details);
        // MARQUE, TYPE VOLUME PRIX CODE BAR
        init();

     /// TODO HNAAA PAGAAAAAA TA3 MIN TECLICKI 3LA RECYCLER VIEW
        getData();
        setData();
    }
    private void init(){
        Marque = findViewById(R.id.idMarque);
        Type = findViewById(R.id.idType);
        Volume = findViewById(R.id.idVolume);
        Prix = findViewById(R.id.idPrix);
        Code_Bar = findViewById(R.id.idCode_Bar);
        Composition = findViewById(R.id.idComposition);
        Energie = findViewById(R.id.idEnergie);
        Matiere_Graisse = findViewById(R.id.idMatiere_Graisse);
        Graisse_Sature = findViewById(R.id.idGraisse_Sature);
        Glucides = findViewById(R.id.idGlucides);
        Sucre = findViewById(R.id.idSucre);
        Proteine = findViewById(R.id.idProteine);
        Sodium = findViewById(R.id.idSodium);
        Sel = findViewById(R.id.idSel);
    }

    private void getData(){

            marque = getIntent().getStringExtra("Marque");
            type = getIntent().getStringExtra("Type");
            volume = getIntent().getStringExtra("Volume");
            prix = getIntent().getStringExtra("Prix");
            code_bar = getIntent().getStringExtra("Code_Bar");
            composition = getIntent().getStringExtra("Composition");
            energie = getIntent().getStringExtra("Energie");
            matiere_graisse = getIntent().getStringExtra("Matiere_Graisse");
            graisse_sature = getIntent().getStringExtra("Graisse_Sature");
            glucides = getIntent().getStringExtra("Glucides");
            sucre = getIntent().getStringExtra("Sucre");
            proteine = getIntent().getStringExtra("Proteine");
            sodium = getIntent().getStringExtra("Sodium");
            sel = getIntent().getStringExtra("Sel");


    }

    private void setData(){
        Marque.setText("Marque : "+marque);
        Type.setText("Type : "+type);
        Volume.setText("Volume : "+volume);
        Prix.setText("Prix : "+prix);
        Code_Bar.setText("Code Bar : "+code_bar);
        Composition.setText("Composition : "+composition);
        Energie.setText("Energie : "+energie);
        Matiere_Graisse.setText("Matiere Graisse : "+matiere_graisse);
        Graisse_Sature.setText("Graisse Sature : "+graisse_sature);
        Glucides.setText("Glucides : "+glucides);
        Sucre.setText("Sucre : "+sucre);
        Proteine.setText("Proteine : "+proteine);
        Sodium.setText("Sodium : "+sodium);
        Sel.setText("Sel : "+sel);

    }
}
