package com.damso.superette.database;


import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.damso.superette.More_Details;
import com.damso.superette.R;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class DetailsFragment extends Fragment {


    private RecyclerView recyclerView;
    private DatabaseHelper databaseHelper;
    private ArrayList<Item> arrayList= new ArrayList<Item>();
    private Cursor cursor;
    private VocabularyAdapter adapter;

    String k;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        ViewGroup viewGroup= (ViewGroup) inflater.inflate(R.layout.fragment_details, container, false);


        /*
        - HNA TROH L LA BASE DE DONNEES
        - NDIRO RECYCLER VIEW
        - TAFFICHILNA GA3 LES ITEMS 3LA HSAB LE NOM F BDD
        - Min TECLiCKI TEDIK L PAGA YJI FIHA GA3 SWALEH TA3 BDD
        - TAFFICHILEK SWALEH LI F BDD
         */

        //HNA YEBDA LCODE
        recyclerView = viewGroup.findViewById(R.id.recycler_view);
        loadDatabase();
        //HNA YAHBES LCODE
        return viewGroup;
    }
    public void loadDatabase(){
        databaseHelper = new DatabaseHelper(getActivity());
        try {
            databaseHelper.checkAndCopyDatabase();
            databaseHelper.openDatabase();
        }catch (SQLException e){
            e.printStackTrace();
        }
        try {
            cursor = databaseHelper.QueryData("select * from items");
            if (cursor != null) {
                if (cursor.moveToFirst()) {
                    do {
                        Item item = new Item();
                        // TODO HNA DIR SETTERS !
                        item.setMarque(cursor.getString(0));
                        item.setType(cursor.getString(1));
                        item.setVolume(cursor.getString(2));
                        item.setPrix(cursor.getString(3));
                        item.setCode_Bar(cursor.getString(4));
                        item.setComposition(cursor.getString(5));
                        item.setEnergie(cursor.getString(6));
                        item.setMatiere_Graisse(cursor.getString(7));
                        item.setGraisse_Sature(cursor.getString(8));
                        item.setGlucides(cursor.getString(9));
                        item.setSucre(cursor.getString(10));
                        item.setProteine(cursor.getString(11));
                        item.setSodium(cursor.getString(12));
                        item.setSel(cursor.getString(13));
                        arrayList.add(item);


                    } while (cursor.moveToNext());
                }
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        adapter = new VocabularyAdapter(getActivity(), arrayList);
        /*adapter.setOnTapListener(new OnTapListener() {
            @Override
            public void OnTapView(int position) {

                Toast.makeText(getContext(), "Click To "+position, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getActivity(), More_Details.class);
                intent.putExtra("Weight", k);
                //intent.putExtra(position.getMarque());
                System.out.println(k);
                startActivity(intent);

            }
        });*/
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(adapter);

    }
}
