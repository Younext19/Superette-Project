package com.damso.superette.database;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.damso.superette.More_Details;
import com.damso.superette.R;

import java.util.Collections;
import java.util.List;

public class VocabularyAdapter extends RecyclerView.Adapter<SetViewHolder> {
    private Activity activity;
    List<Item> items= Collections.emptyList();

    private OnTapListener onTapListener;

    public VocabularyAdapter(Activity activity, List<Item> items){
        this.activity = activity;
        this.items = items;
    }

    @NonNull
    @Override
    public SetViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_list_item, parent, false);


        return new SetViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SetViewHolder holder, final int position) {
        // HNA MANZID WALO

        holder.Marque.setText(items.get(position).getMarque());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //onTapListener.OnTapView(position);
                Intent intent = new Intent(activity, More_Details.class);
                // TODO HNA NZID LES AUTRES TEXTVIEWS TA3 LI YJO F BDD
                String Marque;
                String Type;
                String Volume;
                String Prix;
                String Code_Bar;
                String Composition;
                String Energie;
                String Matiere_Graisse;
                String Graisse_Sature;
                String Glucides;
                String Sucre;
                String Proteine;
                String Sodium;
                String Sel;

                Marque = items.get(position).getMarque();
                Type = items.get(position).getType();
                Volume = items.get(position).getVolume();
                Prix = items.get(position).getPrix();
                Code_Bar = items.get(position).getCode_Bar();
                Composition = items.get(position).getComposition();
                Energie = items.get(position).getEnergie();
                Matiere_Graisse = items.get(position).getMatiere_Graisse();
                Graisse_Sature = items.get(position).getGraisse_Sature();
                Glucides = items.get(position).getGlucides();
                Sucre = items.get(position).getSucre();
                Proteine = items.get(position).getProteine();
                Sodium = items.get(position).getSodium();
                Sel = items.get(position).getSel();

                intent.putExtra("Marque",Marque);
                intent.putExtra("Type",Type);
                intent.putExtra("Volume",Volume);
                intent.putExtra("Prix",Prix);
                intent.putExtra("Code_Bar",Code_Bar);
                intent.putExtra("Composition", Composition);
                intent.putExtra("Energie", Energie);
                intent.putExtra("Matiere_Graisse", Matiere_Graisse);
                intent.putExtra("Graisse_Sature",Graisse_Sature);
                intent.putExtra("Glucides",Glucides);
                intent.putExtra("Sucre",Sucre);
                intent.putExtra("Proteine",Proteine);
                intent.putExtra("Sodium", Sodium);
                intent.putExtra("Sel", Sel);

                activity.startActivity(intent);

            }
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public void setOnTapListener(OnTapListener onTapListener){
        this.onTapListener = onTapListener;
    }
}
