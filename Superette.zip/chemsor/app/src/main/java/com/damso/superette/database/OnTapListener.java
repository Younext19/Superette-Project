package com.damso.superette.database;

public interface OnTapListener {
    public void OnTapView(int position);
}
