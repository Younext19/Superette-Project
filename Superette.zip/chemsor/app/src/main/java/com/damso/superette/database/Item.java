package com.damso.superette.database;

public class Item {
    String Marque;
    String Type;
    String Volume;
    String Prix;
    String Code_Bar;
    String Composition;
    String Energie;
    String Matiere_Graisse;
    String Graisse_Sature;
    String Glucides;
    String Sucre;
    String Proteine;
    String Sodium;
    String Sel;

    public String getMarque() {
        return Marque;
    }

    public void setMarque(String marque) {
        this.Marque = marque;
    }

    public String getType() {
        return Type;
    }

    public void setType(String type) {
        this.Type = type;
    }

    public String getVolume() {
        return Volume;
    }

    public void setVolume(String volume) {

        this.Volume = volume;
    }

    public String getPrix() {
        return Prix;
    }

    public void setPrix(String prix) {
        this.Prix = prix;
    }

    public String getCode_Bar() {
        return Code_Bar;
    }

    public void setCode_Bar(String code_Bar) {
        this.Code_Bar = code_Bar;
    }

    public String getComposition() {
        return Composition;
    }

    public void setComposition(String composition) {
        this.Composition = composition;
    }

    public String getEnergie() {
        return Energie;
    }

    public void setEnergie(String energie) {
        this.Energie = energie;
    }

    public String getMatiere_Graisse() {
        return Matiere_Graisse;
    }

    public void setMatiere_Graisse(String matiere_Graisse) {
        this.Matiere_Graisse = matiere_Graisse;
    }

    public String getGraisse_Sature() {
        return Graisse_Sature;
    }

    public void setGraisse_Sature(String graisse_Sature) {
        this.Graisse_Sature = graisse_Sature;
    }

    public String getGlucides() {
        return Glucides;
    }

    public void setGlucides(String glucides) {
        this.Glucides = glucides;
    }

    public String getSucre() {
        return Sucre;
    }

    public void setSucre(String sucre) {
        this.Sucre = sucre;
    }

    public String getProteine() {
        return Proteine;
    }

    public void setProteine(String proteine) {
        this.Proteine = proteine;
    }

    public String getSodium() {
        return Sodium;
    }

    public void setSodium(String sodium) {
        this.Sodium = sodium;
    }

    public String getSel() {
        return Sel;
    }

    public void setSel(String sel) {
        this.Sel = sel;
    }
}