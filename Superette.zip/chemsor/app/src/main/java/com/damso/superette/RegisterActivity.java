package com.damso.superette;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegisterActivity extends AppCompatActivity {

    Button allergie, Chronique;

    private Button CreateAccountButton;
    private EditText UserPseudo,UserEmail, UserPassword;
    private TextView AlreadyHaveAccountLink;
    CheckBox ShowPassword;
    private FirebaseAuth mAuth;
    private ProgressDialog loadingbar;
    private DatabaseReference RootRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        //final String[] list = new String[]{"Poisson", "Le lait", "Le blé", "Les oeufs","Les arachides",
                //"Les fruits à écailles", "Le soya", "Les fruits de mer"};
        //final String[] list2 = new String[]{"Diabétique", "Hypertension"};


        //Initialise
        initialise();
        mAuth = FirebaseAuth.getInstance();
        RootRef = FirebaseDatabase.getInstance().getReference();

        //___________ON CLICK BUTTON TA3 ALLERGIE______________________
        allergie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //SHOW ALERT DIALOG OF ALLERGIES
                AlertDialog.Builder builder = new AlertDialog.Builder(RegisterActivity.this);

                // String array for alert dialog multi choice items
                String[] Allergies = new String[]{
                        "Poisson","lait","Blé", "Oeufs",
                        "Fruit De mer", "Arachide",
                        "Fruits A écailles"
                };

                // Boolean array for initial selected items
                final boolean[] init = new boolean[]{
                        false,false,
                        false,false,
                        false,false,false
                };

                // Convert Allergies array to list
                final List<String> colorsList = Arrays.asList(Allergies);

                // Set multiple choice items for alert dialog

                builder.setMultiChoiceItems(Allergies, init,
                        new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which, boolean isChecked) {

                        // Update the current focused item's checked status
                        init[which] = isChecked;

                        // Get the current focused item
                        String currentItem = colorsList.get(which);

                        // Notify the current action
                        Toast.makeText(getApplicationContext(),
                                currentItem + " " + isChecked, Toast.LENGTH_SHORT).show();
                    }
                });

                // Specify the dialog is not cancelable
                builder.setCancelable(false);

                // Set a title for alert dialog
                builder.setTitle("Selectionne Tes Allergies");

                // Set the positive/yes button click listener
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // MIN YECLICKI OK GHADI TEDI DATA LI RAHOM TRUE HNA
                        // L ACTIVITY TA3 MAIN W LAZEM YETSAUVGARDAW DATA

                        }

                });


                // Set the negative/no button click listener
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Min Yeclicki cancel tsema maghadi yedi walo l next act
                        // w Fel main kolesh Yetafficha
                    }
                });

                AlertDialog dialog = builder.create();
                // Display the alert dialog on interface
                dialog.show();
            }
        });
        //--------FINISHED ON CLICK BUTTON TA3 ALLERGIE----------------

        //__________ON CLICK BUUTON DE MALADIE CHRONIQUE_____________
        Chronique.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //SHOW ALER DIALOG OF MALADIE CHRONIQUE
            }
        });
        //--------FINSHED ON CLICK BUTTON TA3 MALADIE CHRONIQUE------------

        //________When Click On Already Have An Account_______GO TO LOGIN ACT
        AlreadyHaveAccountLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SendUserToLoginActivity();
            }
        });
        //---------FINISHED ALREADY HAVE AN ACCOUNT---------------


        //________________SHOW/ HIDE PASSWORD_________________
        ShowPassword.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    UserPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
                else{
                    UserPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
            }
        });
        //--------------FINISHED SHOW/HIDE PW----------------




        //____________________WHen Click on CREATE A NEW ACCOUNT__________________
        CreateAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CreateNewAccount();
            }
        });
        //-------------------FINISHED ON CREATE NEW ACCOUNT----------------------

    }


    //__________________Initialiser all buttons ...______________________
    private void initialise() {
        CreateAccountButton=findViewById(R.id.register_final);
        UserEmail=findViewById(R.id.register_mail);
        //UserPseudo=findViewById(R.id.Pseudo);
        UserPassword = findViewById(R.id.register_password);
        AlreadyHaveAccountLink = findViewById(R.id.haveit);
        ShowPassword = findViewById(R.id.Password_Checkbox);
        loadingbar=new ProgressDialog(this);
        allergie = findViewById(R.id.allergie);
        Chronique = findViewById(R.id.chronique);
    }
    //--------------------FINISHED INITIALISATION---------------

    //_____________CREATE NEW ACCOUNT AND SEND TO DATABASE FIREBASE__________________
    private void CreateNewAccount() {
        String email = UserEmail.getText().toString();
        String Password = UserPassword.getText().toString();

        if(TextUtils.isEmpty(email)){
            Toast.makeText(this, "Please Enter Mail", Toast.LENGTH_SHORT).show();
        }
        if(TextUtils.isEmpty(Password)){
            Toast.makeText(this, "Please Enter Password", Toast.LENGTH_SHORT).show();
        }
        else{
            loadingbar.setTitle("Creating New Account");
            loadingbar.setMessage("Please Wait");
            loadingbar.setCanceledOnTouchOutside(true);
            loadingbar.show();

            mAuth.createUserWithEmailAndPassword(email, Password)
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(task.isSuccessful()){
                                String currentUserID = mAuth.getCurrentUser().getUid();
                                RootRef.child("Users").child(currentUserID).setValue("");



                                SendUserToMainActivity();
                                Toast.makeText(RegisterActivity.this, "Created Successfully", Toast.LENGTH_SHORT).show();
                                loadingbar.dismiss();
                            }
                            else
                            {
                                String message=task.getException().toString();
                                Toast.makeText(RegisterActivity.this, "Error : "+message, Toast.LENGTH_SHORT).show();
                                loadingbar.dismiss();
                            }
                        }
                    });
        }
    }
    //---------------FINISHED CREATE NEW ACCOUNT AND SEND TO DATABASE FIREBASE---------------

    //_______________SEND USER TO MAIN ACTIVITY_______________________
    private void SendUserToMainActivity() {
        Intent MainIntent = new Intent(RegisterActivity.this, MainActivity.class);
        MainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(MainIntent);
        finish();
    }
    //-------------FINISHED SEND USER TO MAIN ACTIVITY--------------

    //_______________SEND USER TO LOGIN ACT___________________
    private void SendUserToLoginActivity() {

        Intent LoginIntent = new Intent(RegisterActivity.this, LoginActivity.class);
        startActivity(LoginIntent);
    }
    //--------------Finished Send User TO LOGIN-------------------

    //______________________________PASSWORD VALIDATION________________________
    public static boolean isValidPassword(final String password) {

        Pattern pattern;
        Matcher matcher;
        final String PASSWORD_PATTERN = "^(?=.*[0-9])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{4,}$";
        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);

        return matcher.matches();
    }
    //-------------------------FINISHED PASSWORD VALIDATION----------------------

}
